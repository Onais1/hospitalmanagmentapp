package service;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Owner
 */
public class CustomUserDetailsService {
     @Bean
    public UserDetailsService userDetailsService() {
        var userAdmin = User.withUsername("admin")
                            .password(new BCryptPasswordEncoder().encode("admin123"))
                            .roles("ADMIN")
                            .build();

        var userUser = User.withUsername("user")
                           .password(new BCryptPasswordEncoder().encode("user123"))
                           .roles("USER")
                           .build();

        return new InMemoryUserDetailsManager(userAdmin, userUser);
    }
}
